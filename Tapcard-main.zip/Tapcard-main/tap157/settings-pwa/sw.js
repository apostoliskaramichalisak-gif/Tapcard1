/**
 * Service Worker - Fixed Media Library Access
 * Properly handles file access with correct permissions and caching strategies
 */

const CACHE_NAME = 'tapcard-pwa-v1.7.7';
const RUNTIME_CACHE = 'tapcard-runtime-v1';
const IMAGE_CACHE = 'tapcard-images-v1';

// Files to cache on install
const PRECACHE_URLS = [
    './',
    '../v154-final.css',
    '../app.js',
    '../icon-192.png',
    '../icon-512.png',
    'manifest.php',
    'index.php'
];

/**
 * Install event - Cache essential files
 */
self.addEventListener('install', (event) => {
    console.log('[Service Worker] Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('[Service Worker] Caching essential files');
                return cache.addAll(PRECACHE_URLS).catch((err) => {
                    console.warn('[Service Worker] Some files could not be cached:', err);
                    // Continue even if some files fail to cache
                });
            })
            .then(() => self.skipWaiting())
    );
});

/**
 * Activate event - Clean up old caches
 */
self.addEventListener('activate', (event) => {
    console.log('[Service Worker] Activating...');
    
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE && cacheName !== IMAGE_CACHE) {
                        console.log('[Service Worker] Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

/**
 * Fetch event - Handle network requests with smart caching
 */
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Handle manifest requests with CORS
    if (url.pathname.includes('manifest.php')) {
        event.respondWith(
            fetch(request, {
                mode: 'cors',
                credentials: 'include'
            })
            .then((response) => {
                if (!response || response.status !== 200) {
                    return response;
                }
                
                const responseClone = response.clone();
                caches.open(RUNTIME_CACHE).then((cache) => {
                    cache.put(request, responseClone);
                });
                
                return response;
            })
            .catch(() => caches.match(request))
        );
        return;
    }

    // Handle image requests with image-specific caching
    if (request.method === 'GET' && (url.pathname.includes('image') || 
        request.headers.get('accept')?.includes('image'))) {
        event.respondWith(
            caches.match(request).then((cachedResponse) => {
                if (cachedResponse) {
                    return cachedResponse;
                }

                return fetch(request, {
                    mode: 'cors',
                    credentials: 'include'
                })
                .then((response) => {
                    if (!response || response.status !== 200 || response.type === 'error') {
                        return response;
                    }

                    const responseClone = response.clone();
                    caches.open(IMAGE_CACHE).then((cache) => {
                        cache.put(request, responseClone);
                    });

                    return response;
                })
                .catch((error) => {
                    console.warn('[Service Worker] Fetch failed for image:', request.url, error);
                    // Return a fallback image or error response
                    return caches.match(request) || 
                        new Response('Image not available', { status: 404 });
                });
            })
        );
        return;
    }

    // Handle POST requests (file uploads, form submissions)
    if (request.method === 'POST') {
        event.respondWith(
            fetch(request, {
                mode: 'cors',
                credentials: 'include',
                headers: {
                    ...request.headers,
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then((response) => {
                if (response && response.status === 200) {
                    const responseClone = response.clone();
                    caches.open(RUNTIME_CACHE).then((cache) => {
                        cache.put(request, responseClone);
                    });
                }
                return response;
            })
            .catch((error) => {
                console.error('[Service Worker] POST request failed:', request.url, error);
                return new Response(
                    JSON.stringify({ 
                        error: 'Network error. Please check your connection.',
                        message: error.message 
                    }),
                    { 
                        status: 503,
                        headers: { 'Content-Type': 'application/json' }
                    }
                );
            })
        );
        return;
    }

    // Handle CSS, JS, and other assets - Cache first strategy
    if (request.method === 'GET' && 
        (url.pathname.endsWith('.css') || url.pathname.endsWith('.js'))) {
        event.respondWith(
            caches.match(request).then((cachedResponse) => {
                if (cachedResponse) {
                    return cachedResponse;
                }

                return fetch(request, {
                    mode: 'cors',
                    credentials: 'include'
                })
                .then((response) => {
                    if (!response || response.status !== 200) {
                        return response;
                    }

                    const responseClone = response.clone();
                    caches.open(CACHE_NAME).then((cache) => {
                        cache.put(request, responseClone);
                    });

                    return response;
                })
                .catch(() => caches.match(request));
            })
        );
        return;
    }

    // Handle HTML pages - Network first strategy
    if (request.method === 'GET' && url.pathname.endsWith('.php')) {
        event.respondWith(
            fetch(request, {
                mode: 'cors',
                credentials: 'include'
            })
            .then((response) => {
                if (!response || response.status !== 200) {
                    return caches.match(request) || response;
                }

                const responseClone = response.clone();
                caches.open(RUNTIME_CACHE).then((cache) => {
                    cache.put(request, responseClone);
                });

                return response;
            })
            .catch(() => {
                return caches.match(request) || 
                    new Response('Page not available offline', { status: 503 });
            })
        );
        return;
    }

    // Default: Network first, fall back to cache
    event.respondWith(
        fetch(request, {
            mode: 'cors',
            credentials: 'include'
        })
        .then((response) => {
            if (!response || response.status !== 200) {
                return caches.match(request) || response;
            }

            const responseClone = response.clone();
            caches.open(RUNTIME_CACHE).then((cache) => {
                cache.put(request, responseClone);
            });

            return response;
        })
        .catch(() => {
            return caches.match(request) ||
                new Response('Network error', { status: 503 });
        })
    );
});

/**
 * Message event - Handle messages from clients
 */
self.addEventListener('message', (event) => {
    console.log('[Service Worker] Message received:', event.data);

    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }

    if (event.data && event.data.type === 'CLEAR_CACHE') {
        caches.keys().then((cacheNames) => {
            Promise.all(
                cacheNames.map((cacheName) => caches.delete(cacheName))
            ).then(() => {
                event.ports[0].postMessage({ success: true });
            });
        });
    }

    if (event.data && event.data.type === 'GET_CACHE_SIZE') {
        if ('storage' in navigator && 'estimate' in navigator.storage) {
            navigator.storage.estimate().then((estimate) => {
                event.ports[0].postMessage({
                    usage: estimate.usage,
                    quota: estimate.quota
                });
            });
        }
    }
});

/**
 * Handle push notifications
 */
self.addEventListener('push', (event) => {
    console.log('[Service Worker] Push notification received');

    const options = {
        body: event.data?.text() || 'Ειδοποίηση από Tapcard',
        icon: '../assets/icon-192.png',
        badge: '../assets/icon-192.png',
        tag: 'tapcard-notification',
        requireInteraction: false
    };

    event.waitUntil(
        self.registration.showNotification('Tapcard', options)
    );
});

/**
 * Handle notification clicks
 */
self.addEventListener('notificationclick', (event) => {
    console.log('[Service Worker] Notification clicked');

    event.notification.close();

    event.waitUntil(
        clients.matchAll({ type: 'window' }).then((clientList) => {
            for (let i = 0; i < clientList.length; i++) {
                const client = clientList[i];
                if (client.url === '/' && 'focus' in client) {
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                return clients.openWindow('./');
            }
        })
    );
});

/**
 * Handle sync events (background sync)
 */
self.addEventListener('sync', (event) => {
    console.log('[Service Worker] Sync event:', event.tag);

    if (event.tag === 'sync-images') {
        event.waitUntil(
            // Sync image uploads or operations
            Promise.resolve().then(() => {
                console.log('[Service Worker] Syncing images...');
            })
        );
    }
});

console.log('[Service Worker] Loaded and ready');
