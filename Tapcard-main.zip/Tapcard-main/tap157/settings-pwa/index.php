<?php
/**
 * PWA Settings - Image Picker
 * Fixed media library access with proper permissions
 */

// Set headers to prevent caching issues
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight CORS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Check for proper permissions
$allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
?>
<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Επιλογή εικόνας από βιβλιοθήκη">
    <title>Επιλογή Εικόνας - Tapcard</title>
    <link rel="manifest" href="manifest.php">
    <link rel="stylesheet" href="../v154-final.css">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-top: 0;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 15px;
            display: none;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 15px;
            display: none;
            border-left: 4px solid #3c3;
        }
        .file-input-wrapper {
            position: relative;
            display: inline-block;
            cursor: pointer;
            margin: 10px 0;
        }
        .file-input-wrapper input[type="file"] {
            position: absolute;
            left: -9999px;
            opacity: 0;
        }
        .file-input-label {
            display: inline-block;
            padding: 12px 24px;
            background: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
            font-weight: 600;
        }
        .file-input-label:hover {
            background: #0056b3;
        }
        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 30px;
        }
        .gallery-item {
            position: relative;
            aspect-ratio: 1;
            border-radius: 8px;
            overflow: hidden;
            background: #eee;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .gallery-item:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .gallery-item.selected {
            border: 3px solid #007bff;
            box-shadow: 0 0 0 2px white, 0 0 0 4px #007bff;
        }
        .loading {
            text-align: center;
            padding: 30px;
            color: #666;
        }
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }
        .btn-primary {
            background: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #007bff;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📸 Επιλογή Εικόνας</h1>
        
        <div class="error" id="errorMsg"></div>
        <div class="success" id="successMsg"></div>
        
        <div class="info-box">
            <strong>💡 Συμβουλή:</strong> Μπορείτε να φορτώσετε εικόνα κλικάροντας το κουμπί παρακάτω ή σύροντάς την εδώ.
        </div>

        <div class="file-input-wrapper" id="dropZone">
            <input type="file" id="imageInput" accept="image/*" multiple>
            <label for="imageInput" class="file-input-label">📁 Επιλέξτε Εικόνα από Βιβλιοθήκη</label>
        </div>

        <div class="loading" id="loadingIndicator" style="display: none;">
            <div class="loading-spinner"></div>
            <p>Φόρτωση εικόνων...</p>
        </div>

        <div class="gallery" id="gallery"></div>

        <div class="actions" id="actions" style="display: none;">
            <button class="btn-primary" id="confirmBtn">✓ Επιβεβαίωση Επιλογής</button>
            <button class="btn-secondary" id="cancelBtn">✕ Ακύρωση</button>
        </div>
    </div>

    <script>
        // Image picker functionality with proper error handling
        class ImagePicker {
            constructor() {
                this.selectedImage = null;
                this.images = [];
                this.fileInput = document.getElementById('imageInput');
                this.dropZone = document.getElementById('dropZone');
                this.gallery = document.getElementById('gallery');
                this.errorMsg = document.getElementById('errorMsg');
                this.successMsg = document.getElementById('successMsg');
                this.loadingIndicator = document.getElementById('loadingIndicator');
                this.actionsDiv = document.getElementById('actions');
                
                this.init();
            }

            init() {
                // File input change
                this.fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
                
                // Drag and drop
                this.dropZone.addEventListener('dragover', (e) => this.handleDragOver(e));
                this.dropZone.addEventListener('dragleave', (e) => this.handleDragLeave(e));
                this.dropZone.addEventListener('drop', (e) => this.handleDrop(e));
                
                // Action buttons
                document.getElementById('confirmBtn').addEventListener('click', () => this.confirmSelection());
                document.getElementById('cancelBtn').addEventListener('click', () => this.cancel());

                // Load existing images
                this.loadImages();
            }

            handleFileSelect(event) {
                const files = Array.from(event.target.files);
                this.processFiles(files);
            }

            handleDragOver(event) {
                event.preventDefault();
                event.stopPropagation();
                this.dropZone.style.background = '#f0f0f0';
                this.dropZone.style.borderColor = '#007bff';
            }

            handleDragLeave(event) {
                event.preventDefault();
                event.stopPropagation();
                this.dropZone.style.background = '';
                this.dropZone.style.borderColor = '';
            }

            handleDrop(event) {
                event.preventDefault();
                event.stopPropagation();
                this.dropZone.style.background = '';
                
                const files = Array.from(event.dataTransfer.files);
                const imageFiles = files.filter(file => file.type.startsWith('image/'));
                
                if (imageFiles.length === 0) {
                    this.showError('Παρακαλώ σύρετε μόνο εικόνες');
                    return;
                }
                
                this.processFiles(imageFiles);
            }

            processFiles(files) {
                const validFiles = files.filter(file => {
                    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
                    if (!validTypes.includes(file.type)) {
                        this.showError(`Μη υποστηριζόμενος τύπος αρχείου: ${file.type}`);
                        return false;
                    }
                    return true;
                });

                if (validFiles.length === 0) return;

                this.loadingIndicator.style.display = 'block';
                
                validFiles.forEach((file, index) => {
                    const reader = new FileReader();
                    
                    reader.onload = (e) => {
                        this.images.push({
                            name: file.name,
                            data: e.target.result,
                            type: file.type,
                            size: file.size
                        });
                        
                        if (index === validFiles.length - 1) {
                            this.renderGallery();
                            this.loadingIndicator.style.display = 'none';
                            this.showSuccess(`${validFiles.length} εικόνα(ες) φορτώθηκε(αν) επιτυχώς`);
                        }
                    };
                    
                    reader.onerror = () => {
                        this.showError(`Σφάλμα κατά την ανάγνωση του αρχείου: ${file.name}`);
                        this.loadingIndicator.style.display = 'none';
                    };
                    
                    reader.readAsDataURL(file);
                });
            }

            renderGallery() {
                this.gallery.innerHTML = '';
                
                this.images.forEach((img, index) => {
                    const item = document.createElement('div');
                    item.className = 'gallery-item';
                    if (this.selectedImage === index) {
                        item.classList.add('selected');
                    }
                    
                    const imgElement = document.createElement('img');
                    imgElement.src = img.data;
                    imgElement.alt = img.name;
                    imgElement.loading = 'lazy';
                    
                    item.appendChild(imgElement);
                    item.addEventListener('click', () => this.selectImage(index));
                    
                    this.gallery.appendChild(item);
                });

                if (this.images.length > 0) {
                    this.actionsDiv.style.display = 'flex';
                }
            }

            selectImage(index) {
                this.selectedImage = index;
                this.renderGallery();
                this.showSuccess('Εικόνα επιλέχθηκε');
            }

            confirmSelection() {
                if (this.selectedImage === null) {
                    this.showError('Παρακαλώ επιλέξτε εικόνα');
                    return;
                }

                const image = this.images[this.selectedImage];
                
                // Send to parent window
                if (window.opener) {
                    window.opener.postMessage({
                        type: 'IMAGE_SELECTED',
                        image: {
                            src: image.data,
                            name: image.name,
                            type: image.type,
                            size: image.size
                        }
                    }, '*');
                    window.close();
                } else {
                    // Fallback for iframe
                    localStorage.setItem('selectedImage', JSON.stringify(image));
                    this.showSuccess('Εικόνα αποθηκεύτηκε');
                }
            }

            cancel() {
                if (window.opener) {
                    window.close();
                } else {
                    window.history.back();
                }
            }

            loadImages() {
                // Try to load from localStorage or IndexedDB
                try {
                    const stored = localStorage.getItem('tapcard_images');
                    if (stored) {
                        this.images = JSON.parse(stored);
                        this.renderGallery();
                    }
                } catch (error) {
                    console.warn('Δεν ήταν δυνατή η φόρτωση αποθηκευμένων εικόνων:', error);
                }
            }

            showError(message) {
                this.errorMsg.textContent = message;
                this.errorMsg.style.display = 'block';
                setTimeout(() => {
                    this.errorMsg.style.display = 'none';
                }, 5000);
            }

            showSuccess(message) {
                this.successMsg.textContent = message;
                this.successMsg.style.display = 'block';
                setTimeout(() => {
                    this.successMsg.style.display = 'none';
                }, 3000);
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', () => {
            new ImagePicker();
        });

        // Register service worker if available
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js').catch(err => {
                console.warn('Service Worker registration failed:', err);
            });
        }
    </script>
</body>
</html>
