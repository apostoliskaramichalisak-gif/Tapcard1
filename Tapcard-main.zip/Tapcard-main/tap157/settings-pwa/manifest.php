<?php
/**
 * PWA Manifest - Fixed Permissions
 * Added proper permissions for media library access
 */

header('Content-Type: application/manifest+json; charset=utf-8');

$manifest = [
    "name" => "Tapcard Pro",
    "short_name" => "Tapcard",
    "description" => "NFC tap and QR code scan for v cards, social etc",
    "start_url" => "./",
    "scope" => "./",
    "display" => "standalone",
    "orientation" => "portrait-primary",
    "background_color" => "#ffffff",
    "theme_color" => "#007bff",
    
    // FIXED: Added proper permissions for media library access
    "permissions" => [
        "storage",
        "media",
        "photos"
    ],
    
    // FIXED: Added proper icons configuration
    "icons" => [
        [
            "src" => "../assets/icon-192.png",
            "sizes" => "192x192",
            "type" => "image/png",
            "purpose" => "any"
        ],
        [
            "src" => "../assets/icon-512.png",
            "sizes" => "512x512",
            "type" => "image/png",
            "purpose" => "any"
        ],
        [
            "src" => "../assets/icon-192.png",
            "sizes" => "192x192",
            "type" => "image/png",
            "purpose" => "maskable"
        ]
    ],
    
    // FIXED: Added screenshots for PWA installation
    "screenshots" => [
        [
            "src" => "../assets/icon-192.png",
            "sizes" => "192x192",
            "type" => "image/png",
            "form_factor" => "narrow"
        ],
        [
            "src" => "../assets/icon-512.png",
            "sizes" => "512x512",
            "type" => "image/png",
            "form_factor" => "wide"
        ]
    ],
    
    // FIXED: Added categories for app store
    "categories" => [
        "productivity",
        "utilities"
    ],
    
    // FIXED: Proper file handling
    "file_handlers" => [
        [
            "action" => "./",
            "accept" => [
                "image/*" => [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"]
            ],
            "icons" => [
                [
                    "src" => "../assets/icon-192.png",
                    "sizes" => "192x192"
                ]
            ]
        ]
    ],
    
    // FIXED: Share target configuration
    "share_target" => [
        "action" => "./",
        "method" => "POST",
        "enctype" => "multipart/form-data",
        "params" => [
            "title" => "title",
            "text" => "text",
            "url" => "url",
            "files" => [
                [
                    "name" => "image",
                    "accept" => ["image/*"]
                ]
            ]
        ]
    ],
    
    // FIXED: Protocol handlers
    "protocol_handlers" => [
        [
            "protocol" => "web+tapcard",
            "url" => "./?action=protocol&url=%s"
        ]
    ],
    
    // FIXED: Shortcuts for quick actions
    "shortcuts" => [
        [
            "name" => "Επιλογή Εικόνας",
            "short_name" => "Εικόνα",
            "description" => "Επιλέξτε εικόνα από τη βιβλιοθήκη σας",
            "url" => "./",
            "icons" => [
                [
                    "src" => "../assets/icon-192.png",
                    "sizes" => "192x192"
                ]
            ]
        ]
    ],
    
    // FIXED: Proper PWA-specific settings
    "prefer_related_applications" => false,
    "related_applications" => [],
    
    // FIXED: Enable launch handler
    "launch_handler" => [
        "client_mode" => ["navigate-new", "auto"]
    ]
];

// CORS headers for proper access
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Output manifest as JSON
echo json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
